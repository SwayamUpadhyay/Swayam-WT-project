// ─── DATA STORE ───
let products = [
  { id: 1, name: "Vintage Denim Jacket", price: 450, category: "Clothing", condition: "Good", image: "https://images.unsplash.com/photo-1551537482-f2075a1d41f2?w=400", seller: "Priya S.", sold: false },
  { id: 2, name: "Retro Leather Bag", price: 650, category: "Accessories", condition: "Excellent", image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400", seller: "Amit K.", sold: false },
  { id: 3, name: "Floral Midi Dress", price: 300, category: "Clothing", condition: "Like New", image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400", seller: "Sneha R.", sold: false },
  { id: 4, name: "Wooden Bookshelf", price: 900, category: "Furniture", condition: "Good", image: "https://images.unsplash.com/photo-1594620302200-9a762244a156?w=400", seller: "Rahul M.", sold: false },
  { id: 5, name: "Polaroid Camera", price: 1200, category: "Electronics", condition: "Excellent", image: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=400", seller: "Nisha T.", sold: false },
  { id: 6, name: "Vintage Sunglasses", price: 250, category: "Accessories", condition: "Like New", image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400", seller: "Karan V.", sold: false },
];

let cart = [];
let nextId = 7;
let activeCategory = "All";
const CATEGORIES = ["All", "Clothing", "Accessories", "Furniture", "Electronics"];

// ─── TOAST ───
function showToast(msg, type = "success") {
  const icons = { success: "✅", error: "❌", info: "ℹ️" };
  const t = document.getElementById("toast");
  document.getElementById("toast-msg").textContent = msg;
  document.getElementById("toast-icon").textContent = icons[type] || "✅";
  t.className = `toast ${type} show`;
  setTimeout(() => t.classList.remove("show"), 3500);
}

// ─── PAGE ROUTING ───
function showPage(name) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav-btn, .cart-nav").forEach(b => b.classList.remove("active"));
  document.getElementById("page-" + name).classList.add("active");
  document.getElementById("nav-" + name).classList.add("active");
  window.scrollTo({ top: 0, behavior: "smooth" });
  if (name === "cart") renderCart();
  if (name === "shop") renderProducts();
}

// ─── CATEGORIES ───
function renderCats() {
  const container = document.getElementById("cats-container");
  container.innerHTML = CATEGORIES.map(c => `
    <button class="cat-btn${c === activeCategory ? " active" : ""}" onclick="selectCat('${c}')">${c}</button>
  `).join("");
}

function selectCat(cat) {
  activeCategory = cat;
  renderCats();
  renderProducts();
}

// ─── PRODUCTS ───
function getFilteredProducts() {
  const search = document.getElementById("search-input").value.toLowerCase();
  return products.filter(p =>
    (activeCategory === "All" || p.category === activeCategory) &&
    (!search || p.name.toLowerCase().includes(search))
  );
}

function inCart(id) { return cart.some(c => c.id === id); }

function renderProducts() {
  const filtered = getFilteredProducts();
  document.getElementById("stat-products").textContent = products.length;
  document.getElementById("results-count").textContent = `${filtered.length} item${filtered.length !== 1 ? "s" : ""}`;

  const grid = document.getElementById("products-grid");
  if (filtered.length === 0) {
    grid.innerHTML = `<div class="no-results"><div class="no-icon">🔍</div><h3>Nothing found</h3><p>Try a different search or category.</p></div>`;
    return;
  }

  grid.innerHTML = filtered.map(p => `
    <div class="product-card${p.sold ? " is-sold" : ""}">
      <div class="card-img">
        <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400'">
        ${p.sold ? `<span class="tag tag-sold">Sold</span>` : ""}
        <span class="tag tag-condition">${p.condition}</span>
        <button class="card-wishlist" title="Wishlist">🤍</button>
      </div>
      <div class="card-body">
        <div class="card-meta">
          <span class="card-category">${p.category}</span>
          <span class="card-seller">by ${p.seller}</span>
        </div>
        <div class="card-name">${p.name}</div>
        <div class="card-footer">
          <div class="card-price"><sup>₹</sup>${p.price.toLocaleString("en-IN")}</div>
          <button class="add-btn${inCart(p.id) ? " in-cart" : ""}"
            ${p.sold || inCart(p.id) ? "disabled" : `onclick="addToCart(${p.id})"`}>
            ${p.sold ? "Sold Out" : inCart(p.id) ? "In Cart ✓" : "Add to Cart"}
          </button>
        </div>
      </div>
    </div>
  `).join("");
}

function filterProducts() { renderProducts(); }

// ─── CART ───
function addToCart(id) {
  const product = products.find(p => p.id === id);
  if (!product || product.sold || inCart(id)) return;
  cart.push(product);
  updateCartBadge();
  renderProducts();
  showToast(`${product.name} added to cart!`, "success");
}

function removeFromCart(id) {
  cart = cart.filter(p => p.id !== id);
  updateCartBadge();
  renderCart();
  showToast("Removed from cart", "info");
}

function updateCartBadge() {
  const badge = document.getElementById("cart-badge");
  if (cart.length > 0) {
    badge.style.display = "inline";
    badge.textContent = cart.length;
  } else {
    badge.style.display = "none";
  }
}

function renderCart() {
  const cartEmpty = document.getElementById("cart-empty");
  const cartLayout = document.getElementById("cart-layout");

  if (cart.length === 0) {
    cartEmpty.style.display = "block";
    cartLayout.style.display = "none";
    return;
  }
  cartEmpty.style.display = "none";
  cartLayout.style.display = "grid";

  const total = cart.reduce((s, p) => s + p.price, 0);
  document.getElementById("sum-sub").textContent = "₹" + total.toLocaleString("en-IN");
  document.getElementById("sum-total").textContent = "₹" + total.toLocaleString("en-IN");

  document.getElementById("cart-items-list").innerHTML = cart.map(p => `
    <div class="cart-item">
      <img class="cart-item-img" src="${p.image}" alt="${p.name}" onerror="this.src='https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400'">
      <div class="cart-item-info">
        <div class="cart-item-name">${p.name}</div>
        <div class="cart-item-meta">${p.category} · ${p.condition} · ${p.seller}</div>
      </div>
      <div class="cart-item-price">₹${p.price.toLocaleString("en-IN")}</div>
      <button class="remove-btn" onclick="removeFromCart(${p.id})" title="Remove">✕</button>
    </div>
  `).join("");
}

function checkout() {
  if (cart.length === 0) return;
  const total = cart.reduce((s, p) => s + p.price, 0);
  cart.forEach(item => {
    const p = products.find(x => x.id === item.id);
    if (p) p.sold = true;
  });
  cart = [];
  updateCartBadge();
  showToast(`🎉 Order placed! Total: ₹${total.toLocaleString("en-IN")}`, "success");
  showPage("shop");
}

// ─── SELL FORM ───
function updateCharCount(input, countId) {
  document.getElementById(countId).textContent = input.value.length;
}

function validateForm() {
  const name = document.getElementById("f-name").value.trim();
  const price = document.getElementById("f-price").value;
  document.getElementById("submit-btn").disabled = !name || !price || Number(price) < 1;
}

function previewImage(input) {
  const preview = document.getElementById("img-preview");
  const url = input.value.trim();
  if (url) {
    preview.innerHTML = `<img src="${url}" alt="Preview" onerror="this.parentElement.innerHTML='<span>⚠️ Invalid image URL</span>'">`;
  } else {
    preview.innerHTML = `<span>📷 Preview will appear here</span>`;
  }
}

function listItem() {
  const name = document.getElementById("f-name").value.trim();
  const price = document.getElementById("f-price").value;
  const category = document.getElementById("f-category").value;
  const condition = document.getElementById("f-condition").value;
  const seller = document.getElementById("f-seller").value.trim() || "Anonymous";
  const image = document.getElementById("f-image").value.trim() || "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400";

  if (!name || !price) return;

  const newProduct = { id: nextId++, name, price: Number(price), category, condition, image, seller, sold: false };
  products.push(newProduct);

  ["f-name","f-price","f-image","f-seller"].forEach(id => document.getElementById(id).value = "");
  document.getElementById("name-count").textContent = "0";
  document.getElementById("img-preview").innerHTML = `<span>📷 Preview will appear here</span>`;
  document.getElementById("submit-btn").disabled = true;

  showToast(`${name} listed successfully! ✨`, "success");
  showPage("shop");
}

// ─── INIT ───
renderCats();
renderProducts();
